<?php

namespace App\Http\Controllers;

use App\Exports\ExportUser;
use App\Http\Requests\ExcelUrlRequest;
use App\Http\Resources\ExcelUrlResource;
use App\Models\ExcelUrl;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Excel;

class ExcelUrlController extends Controller
{
    protected $excel;

    public function __construct(Excel $excel)
    {
        $this->url = Config::get('url.localhost');
        $this->excel = $excel;
    }

    public function store(ExcelUrlRequest $request)
    {

    }

    public function index()
    {
        return ExcelUrlResource::collection(ExcelUrl::all());
    }

    public function userExport()
    {
//        $admin = auth()->user();
//        if (! $admin->isAdmin()) {
//            return $this->resUserNotAdmin();
//        }
//
//        $excelData['name'] = 'File User';
//        $excelData['type'] = 'user';
//        do {
//            $excelData['id'] = 'excel-'.Str::uuid();
//        } while (ExcelUrl::where('id', $excelData['id'])->exists());
//
//        $this->excel->store(new ExportUser(), 'user'.now()->format('Y-m-d').'.xlsx', 'local');
//        $excelData['url'] = $this->url.Storage::url('user'.now()->format('Y-m-d').'.xlsx');
//
//        $excel = ExcelUrl::create($excelData);
//        $excel = new ExcelUrlResource($excel);
//
//        return $this->resStoreData($excel);

        return $this->excel->download(new ExportUser(), 'List Siswa ~ '.now()->format('Y-m-d H:i:s').'.xlsx');
    }
}
