<?php

return [
    'nama' => env('ADMIN_NAMA'),
    'password' => env('ADMIN_PASSWORD'),
];
